#!/bin/bash

# Reload configuration files without restarting the server
# Sends SIGHUP to nostr-server, which reloads all JSON configs
# and broadcasts a refresh to connected browsers via SSE

# Check if server is running
PID=$(pgrep -f "^./nostr-server$")

if [ -z "$PID" ]; then
    echo "Error: nostr-server is not running"
    exit 1
fi

# Handle multiple instances
if [ $(echo "$PID" | wc -l) -gt 1 ]; then
    echo "Warning: Multiple instances found:"
    echo "$PID"
    echo "Reloading all..."
fi

echo "Sending SIGHUP to nostr-server (PID: $PID)..."
kill -HUP $PID

echo ""
echo "Config reloaded:"
echo "  - config/actions.json"
echo "  - config/navigation.json"
echo "  - config/relays.json"
echo "  - config/i18n/*.json"
echo ""
echo "Connected browsers will auto-refresh via SSE."
