#!/bin/bash

# Dynamic startup script for nostr-hypermedia
# Usage: ./start.sh [flags]
#
# Flags:
#   --dev       Enable DEV_MODE (persistent keypair)
#   --redis     Enable Redis caching (uses REDIS_URL from .env or default)
#   --no-gzip   Disable gzip compression
#   --debug     Set LOG_LEVEL=debug
#   --port N    Set server port (default: 3000)
#   --help      Show this help message

set -e

# Show help
if [[ "$1" == "--help" || "$1" == "-h" ]]; then
    sed -n '3,12p' "$0"
    exit 0
fi

# Load .env if exists (for secrets like GIPHY_API_KEY, CSRF_SECRET)
if [ -f .env ]; then
    export $(grep -v '^#' .env | grep -v '^$' | xargs)
fi

# Defaults
export PORT="${PORT:-3000}"
export GZIP_ENABLED="${GZIP_ENABLED:-1}"

# Parse flags
while [[ $# -gt 0 ]]; do
    case $1 in
        --dev)
            export DEV_MODE=1
            ;;
        --redis)
            export REDIS_URL="${REDIS_URL:-redis://localhost:6379/0}"
            ;;
        --no-gzip)
            unset GZIP_ENABLED
            ;;
        --debug)
            export LOG_LEVEL=debug
            ;;
        --port)
            export PORT="$2"
            shift
            ;;
        *)
            echo "Unknown option: $1"
            echo "Use --help for usage"
            exit 1
            ;;
    esac
    shift
done

# Show config
echo "Starting server with:"
echo "  PORT=$PORT"
[ -n "$DEV_MODE" ] && echo "  DEV_MODE=1"
[ -n "$REDIS_URL" ] && echo "  REDIS_URL=$REDIS_URL"
[ -n "$GZIP_ENABLED" ] && echo "  GZIP_ENABLED=1"
[ -n "$LOG_LEVEL" ] && echo "  LOG_LEVEL=$LOG_LEVEL"
[ -n "$GIPHY_API_KEY" ] && echo "  GIPHY_API_KEY=***"
echo ""

# Run
exec ./nostr-server
